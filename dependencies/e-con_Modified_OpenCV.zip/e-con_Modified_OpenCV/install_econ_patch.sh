\cp -u Linux/src/OpenCV_2.4.9/cap_v4l.cpp ../opencv/modules/highgui/src
